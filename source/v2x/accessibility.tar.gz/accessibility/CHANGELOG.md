# CHANGELOG

My changelog and working notes...
13. Oct. 2019:
    - split the version 1 code from the version 2 code.
    - renamed all version 2 files to work with the .ins / .dtx paradigm
    - borrowed a CTAN make file from the LNI Project (https://github.com/gi-ev/LNI) to correctly structure the .zip file that I will submit to CTAN
    - split the samples out into their own directories, separate from the source files
